$(".mobile-sidebar-trigger-right").click(function(){
    $("aside").show();
    $("aside").addClass("open-mobile");
});
$(".close-side").click(function(){
    $("aside").hide();
    $("aside").removeClass("open-mobile");
});
$(".top-menu .mobile-hamburger").click(function(){
    $(".top-menu .buttons-actions").toggle();
});
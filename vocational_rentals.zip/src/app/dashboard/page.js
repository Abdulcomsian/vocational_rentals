import Cardpage from "./cardpage/page";
import Layout from "./layout";

function Textpage() {
  return (
    <>
      <Layout>
        <Cardpage />
      </Layout>
    </>
  );
}
export default Textpage;
